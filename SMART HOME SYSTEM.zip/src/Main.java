import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Time;
import java.time.LocalDateTime;
import java.util.Collections;
import java.util.Comparator;

//STAY STRONG SIR.
public class Main {
    public static void main(String[] args) throws IOException {
        ReaderAndWriter IamSoSorryForYourLoss_IamAlwaysHereForSupport = new ReaderAndWriter(args[0],args[1]);
        IamSoSorryForYourLoss_IamAlwaysHereForSupport.readFile();
    }
}